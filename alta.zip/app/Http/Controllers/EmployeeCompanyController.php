<?php

namespace App\Http\Controllers;

use App\EmployeeCompany;
use Illuminate\Http\Request;

class EmployeeCompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\EmployeeCompany  $employeeCompany
     * @return \Illuminate\Http\Response
     */
    public function show(EmployeeCompany $employeeCompany)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\EmployeeCompany  $employeeCompany
     * @return \Illuminate\Http\Response
     */
    public function edit(EmployeeCompany $employeeCompany)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\EmployeeCompany  $employeeCompany
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EmployeeCompany $employeeCompany)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\EmployeeCompany  $employeeCompany
     * @return \Illuminate\Http\Response
     */
    public function destroy(EmployeeCompany $employeeCompany)
    {
        //
    }
}
